# ai/

Anbindung an das Sprachmodell und die Pipeline-Layer:

1. Conversation — was sagt der Nutzer?
2. Structure — Situation / Gedanke / Emotion / Verhalten
3. Reasoning — mögliche Erklärungen
4. Counter-check — Gegenprüfung
5. Strategy — konkreter nächster Schritt
6. Memory — was ist langfristig relevant?
7. Safety — muss vor Memory laufen (siehe safety/safety_rules.md)

System-Prompt liegt in `../prompts/system_prompt.md`.
Noch keine Implementierung — Platzhalter für Schritt 6 des Bauplans.
